# 📦 Инструкция по переносу проекта

## На новом компьютере выполните:

### 1. Распакуйте архив
```bash
tar -xzf tg_groups_api_transfer_*.tar.gz
cd tg_groups_api
```

### 2. Создайте виртуальное окружение
```bash
python3 -m venv .venv
source .venv/bin/activate  # Linux/Mac
# или
.venv\Scripts\activate  # Windows
```

### 3. Установите зависимости
```bash
pip install -r requirements.txt
```

### 4. Настройте секретные файлы

#### Если .env не было в архиве, создайте его:
```bash
# Скопируйте .env.example или создайте вручную
nano .env
```

Добавьте необходимые переменные окружения:
```
TG_API_ID=ваш_api_id
TG_API_HASH=ваш_api_hash
TG_SESSION_STRING=ваша_сессия
# И другие переменные если нужны
```

#### Проверьте session файл:
```bash
ls -la *.session
```

Если session файл отсутствует, создайте его:
```bash
python login.py
```

### 5. Запустите локально
```bash
./start.sh
# или
uvicorn app:app --host 0.0.0.0 --port 8010
```

### 6. Проверьте работоспособность
```bash
curl http://localhost:8010/health
```

## Важные файлы

- `*.session` - Telegram сессия (важно сохранить!)
- `.env` - Переменные окружения (если был в архиве)
- `requirements.txt` - Зависимости Python
- `app.py` - Главный файл приложения
- `tg_service.py` - Telegram сервис

## Деплой на Render

Если нужно задеплоить на Render, см. `DEPLOY.md` или `QUICK_DEPLOY.md`

## Проблемы?

- Если не работает сессия - запустите `python login.py`
- Если не работает .env - проверьте переменные окружения
- Если ошибки импорта - проверьте `pip install -r requirements.txt`
